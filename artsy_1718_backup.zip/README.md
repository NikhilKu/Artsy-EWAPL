artsy_1718
